package si.uni_lj.fe.seminar.autorecipe;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Callable;

class SendLoginInformation implements Callable<String> {
    private final String nickname;
    private final String password;
    private final String serviceURL;
    private final Activity callerActivity;

    public SendLoginInformation(String nickname, String password, Activity callerActivity) {
        this.nickname = nickname;
        this.password = password;
        this.callerActivity = callerActivity;
        serviceURL = callerActivity.getString(R.string.URL_login);
    }

    @Override
    public String call() {
        ConnectivityManager connMgr = (ConnectivityManager) callerActivity.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo;

        try {
            networkInfo = connMgr.getActiveNetworkInfo();
        } catch (Exception e) {
            //je v manifestu dovoljenje za uporabo omrezja?
            return callerActivity.getResources().getString(R.string.network_error);
        }
        if (networkInfo != null && networkInfo.isConnected()) {
            try {
                return connect(nickname, password);

            } catch (IOException e) {
                e.printStackTrace();
                System.out.println(e);
                return callerActivity.getResources().getString(R.string.service_error);
            }
        } else {
            return callerActivity.getResources().getString(R.string.network_error);
        }
    }
    // Given a URL, establishes an HttpUrlConnection and retrieves
    // the content as a InputStream, which it returns as a string.
    private String connect(String nickname, String password) throws IOException {
        URL url = new URL(serviceURL);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setReadTimeout(5000 /* milliseconds */);
        conn.setConnectTimeout(10000 /* milliseconds */);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoInput(true);

        try {
            JSONObject json = new JSONObject();
            json.put("nickname", nickname);
            json.put("password", password);

            // Starts the query
            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            writer.write(json.toString());
            writer.flush();
            writer.close();
            os.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }

        if(conn.getResponseCode() == 200) {
            String response = convertStreamToString(conn.getInputStream());
            String responseCode = ", \"responseCode\":\"" + conn.getResponseCode() + "\"";
            String fullResponse = response.substring(0, response.length()-2) + responseCode + "}";

            return fullResponse;
        }
        else {
            String fullResponse = "{\"token\":\"\", \"responseCode\":\"" + conn.getResponseCode() + "\"}";
            return fullResponse;
        }
    }

    private String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
}
