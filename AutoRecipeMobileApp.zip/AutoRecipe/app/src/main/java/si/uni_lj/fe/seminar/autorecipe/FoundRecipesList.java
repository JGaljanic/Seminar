package si.uni_lj.fe.seminar.autorecipe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FoundRecipesList extends AppCompatActivity {

    ListView recipeList;
    String[] recipeNames;
    String[] recipeIDs;
    String[] recipeThumbnails;
    String recipeID;

    FoundRecipesList foundRecipesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_found_recipes_list);

        this.foundRecipesList = this;

        SharedPreferences prefs = getSharedPreferences("FoundRecipeListData", MODE_PRIVATE);
        String recipeNamesJSON = prefs.getString("FoundRecipeListData", "Recipes not found!");

        // Create a String array recipeNames from the downloaded JSON formatted string of recipe names
        JSONArray jsonArray = null;
        try {
            jsonArray = new JSONArray(recipeNamesJSON);
            recipeNames = new String[jsonArray.length()];
            recipeIDs = new String[jsonArray.length()];
            recipeThumbnails = new String[jsonArray.length()];
            for(int i = 0; i < jsonArray.length(); i++){
                recipeNames[i] = jsonArray.getJSONObject(i).getString("recipe_name");
                recipeIDs[i] = jsonArray.getJSONObject(i).getString("recipe_ID");
                recipeThumbnails[i] = jsonArray.getJSONObject(i).getString("recipe_thumbnail");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Fill out the Listview
        recipeList = findViewById(R.id.recipe_list);
        CustomAdapterRecipeList customAdapter = new CustomAdapterRecipeList(getApplicationContext(), recipeNames, recipeIDs, recipeThumbnails);
        recipeList.setAdapter(customAdapter);

        // Make the elements of the recipeList clickable
        recipeList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView recipeNameView = view.findViewById(R.id.recipe_list_name);
                TextView recipeIDView = view.findViewById(R.id.recipe_list_id);
                TextView recipeThumbnailPathView = view.findViewById(R.id.recipe_list_thumbnail_path);

                recipeID = recipeIDView.getText().toString();

                // On click save the recipe name and thumbnail to be used in the RecipePage activity
                SharedPreferences.Editor editor = getSharedPreferences("selectedRecipeData", MODE_PRIVATE).edit();
                editor.putString("recipeID", recipeID);
                editor.putString("recipeName", recipeNameView.getText().toString());
                editor.putString("recipeThumbnail", recipeThumbnailPathView.getText().toString());
                editor.apply();

                // After that make the request to get other recipe data from the server
                String serviceURL = getResources().getString(R.string.URL_recipe_ID) + recipeID;

                SharedPreferences prefs = getSharedPreferences("Token", MODE_PRIVATE);
                String token = prefs.getString("token", "");

                //Send the recipe_ID to get the recipe data and open the recipe's page
                new AsyncTaskExecutioner().execute(new SendRecipeID(serviceURL, token, foundRecipesList), (recipeIDResult) -> sendRecipeIDAttempt(recipeIDResult));
            }
        });
    }

    public void sendRecipeIDAttempt(String recipeDataJSON) {
        if(!recipeDataJSON.equals("Service error.") && !recipeDataJSON.equals("Network error.") && !recipeDataJSON.equals("Recipe data was not found.")) {
            // Extract data from the received JSON string and save it for the RecipePage activity
            SharedPreferences.Editor editor = getSharedPreferences("selectedRecipeData", MODE_PRIVATE).edit();

            try {
                JSONObject obj = new JSONObject(recipeDataJSON);
                editor.putString("recipeDescription", obj.getString("description"));
                int numberOfSteps = obj.length() - 1;
                for(int i = 1; i <= numberOfSteps; i++){
                    String stepIndex = "step" + i;

                    String stepTextIndex = stepIndex + "_text";
                    String recipeStepText = obj.getJSONObject(stepIndex).getString(stepTextIndex);
                    editor.putString(stepTextIndex, recipeStepText);

                    String stepPictureIndex = stepIndex + "_picture";
                    String recipeStepPicture = obj.getJSONObject(stepIndex).getString(stepPictureIndex);
                    editor.putString(stepPictureIndex, recipeStepPicture);
                }
                editor.putInt("numberOfSteps", numberOfSteps);
                editor.apply();

                //After the description and steps get the recipe's ingredients from the server
                String serviceURL = getResources().getString(R.string.URL_recipe_ID_ingredients) + recipeID;

                SharedPreferences prefs2 = getSharedPreferences("Token", MODE_PRIVATE);
                String token = prefs2.getString("token", "");

                //Send the recipe_ID to get the recipe data and open the recipe's page
                new AsyncTaskExecutioner().execute(new SendRecipeID(serviceURL, token, foundRecipesList), (recipeIDResult) -> sendRecipeIDIngredientsAttempt(recipeIDResult));

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public void sendRecipeIDIngredientsAttempt(String recipeIngredientsJSON) {
        if (!recipeIngredientsJSON.equals("Service error.") && !recipeIngredientsJSON.equals("Network error.") && !recipeIngredientsJSON.equals("Recipe data was not found.")) {
            Intent intent = new Intent(getApplicationContext(), RecipePage.class);

            // Extract data from the received JSON string and save it for the RecipePage activity
            SharedPreferences.Editor editor = getSharedPreferences("selectedRecipeData", MODE_PRIVATE).edit();

            try {
                JSONObject obj = new JSONObject(recipeIngredientsJSON);
                int numberOfIngredients = obj.length();
                String ingredients = "";
                for (int i = 1; i <= numberOfIngredients; i++) {
                    String ingredientIndex = "ingredient" + i;
                    String ingredient = obj.getString(ingredientIndex) + '\n';
                    ingredients = ingredients + ingredient;
                    editor.putString("recipeIngredients", ingredients);
                }
                editor.apply();

                startActivity(intent);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}