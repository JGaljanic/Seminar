package si.uni_lj.fe.seminar.autorecipe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    EditText inputNickname;
    EditText inputPassword;

    TextView inputNicknameError;
    TextView inputPasswordError;

    MainActivity mainActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.mainActivity = this;

        inputNickname = (EditText) findViewById(R.id.login_nickname_input);
        inputPassword = (EditText) findViewById(R.id.login_password_input);

        inputNicknameError = (TextView) findViewById(R.id.login_nickname_error);
        inputPasswordError = (TextView) findViewById(R.id.login_password_error);

        SharedPreferences.Editor editor = getSharedPreferences("Token", MODE_PRIVATE).edit();
        editor.putString("token", "");
        editor.apply();
    }

    public void login(View view) {

        inputNicknameError.setText("");
        inputPasswordError.setText("");

        String nickname = inputNickname.getText().toString();
        String password = inputPassword.getText().toString();
        boolean error = false;

        if (nickname.trim().equalsIgnoreCase("")) {
            inputNicknameError.setText(getResources().getString(R.string.empty_login_username_error));
            error = true;
        }

        if (password.trim().equalsIgnoreCase("")) {
            inputPasswordError.setText(getResources().getString(R.string.empty_login_password_error));
            error = true;
        }

        if (!error) {
            new AsyncTaskExecutioner().execute(new SendLoginInformation(nickname, password, mainActivity), (loginResult) -> loginAttempt(loginResult));
        }
    }

    public void loginAttempt(String responseJSON) {
        String token = "";
        int responseCode = 0;
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(responseJSON);
            token = jsonObject.getString("token");
            responseCode = Integer.parseInt(jsonObject.getString("responseCode"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        switch (responseCode) {
            case 200:
                SharedPreferences.Editor editor = getSharedPreferences("Token", MODE_PRIVATE).edit();
                editor.putString("token", token);
                editor.apply();

                Intent intent = new Intent(this, HomeScreenActivity.class);
                startActivity(intent);
                break;
            case 404:
                inputNicknameError.setText(getResources().getString(R.string.rest_user_doesnt_exist));
                break;
            case 409:
                inputPasswordError.setText(getResources().getString(R.string.rest_wrong_password));
                break;
            default:
                Context context = getApplicationContext();
                CharSequence text = getResources().getString(R.string.rest_login_unsuccessful);
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                break;
        }
    }
}