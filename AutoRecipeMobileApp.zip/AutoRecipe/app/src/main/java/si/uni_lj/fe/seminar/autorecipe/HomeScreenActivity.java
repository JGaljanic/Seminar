package si.uni_lj.fe.seminar.autorecipe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class HomeScreenActivity extends AppCompatActivity {

    private LinearLayout homeScreenLayout;
    private EditText enteredIngredient;
    private int newIngredientId;
    private int newButtonId;
    private int numberOfEnteredIngredients;
    TextView ingredient;
    HomeScreenActivity homeScreenActivity;
    public static final String RECIPE_NAMES = "recipeNames";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        this.homeScreenActivity = this;

        enteredIngredient = (EditText) findViewById(R.id.enter_ingredient_id);
        homeScreenLayout = (LinearLayout) findViewById(R.id.home_screen_layout);
        newIngredientId = 2000001;
        newButtonId = 3000001;
        numberOfEnteredIngredients = 0;
    }

    // When the button is pressed create the next TextView containing the just entered ingredient.
    public void nextIngredient(View view) {

        String entered_ingredient = enteredIngredient.getText().toString();

        LinearLayout ingredientAndButton = new LinearLayout(this);
        TextView ingredientList = new TextView(this);
        Button removeIngredient = new Button(this);

        ingredientAndButton.setGravity(Gravity.CENTER);
        ingredientAndButton.setOrientation(LinearLayout.HORIZONTAL);

        ingredientList.setId(newIngredientId);
        ingredientList.setTextSize(20);
        ingredientList.setText(entered_ingredient);

        removeIngredient.setId(newButtonId);
        removeIngredient.setText("X");
        removeIngredient.setOnClickListener(new View.OnClickListener() {
            public void onClick(View clickedButton) {
                int clickedButtonID = clickedButton.getId();
                int removedIngredientID = clickedButtonID - 1000000;

                View removedIngredient = findViewById(removedIngredientID);

                ((ViewGroup) clickedButton.getParent()).removeView(clickedButton);
                ((ViewGroup) removedIngredient.getParent()).removeView(removedIngredient);

                // Lower the IDs of the TextViews of all the following ingredients by 1 so that the for that makes the URL in the end can find them properly
                // Do the same for the IDs of the remove Buttons so that this onClick function works properly (because of the clickedButtonID - 1000000 bit
                for(int i = clickedButtonID + 1; i <= 3000000 + numberOfEnteredIngredients; i++) {
                    View changedIngredient = findViewById(i - 1000000);
                    View changedButton = findViewById(i);

                    changedIngredient.setId(i - 1000000 - 1);
                    changedButton.setId(i - 1);
                }

                newIngredientId--;
                newButtonId--;
                numberOfEnteredIngredients--;
            }
        });;

        if(entered_ingredient.trim().equalsIgnoreCase("")) {
            enteredIngredient.setError(getResources().getString(R.string.empty_ingredient_input_error));
        }
        else {
            homeScreenLayout.addView(ingredientAndButton);
            ingredientAndButton.addView(ingredientList);
            ingredientAndButton.addView(removeIngredient);

            enteredIngredient.getText().clear();
            homeScreenLayout.invalidate();

            newIngredientId++;
            newButtonId++;
            numberOfEnteredIngredients++;
        }
    }

    // When the button "Send ingredients" is clicked make the connection to the server and get the JSON formatted string of recipe names.
    public void searchRecipes(View view) {

        //Create the URL from the inserted ingredients
        StringBuilder serviceURL = new StringBuilder(getResources().getString(R.string.URL_recipes));
        int ingredientId = 2000001;
        for(int i = 1; i <= numberOfEnteredIngredients; i++) {
            ingredient = (TextView) findViewById(ingredientId);
            String currentIngredient = ingredient.getText().toString();
            if(i != numberOfEnteredIngredients) {
                serviceURL.append("ingredient").append(i).append("=").append(currentIngredient).append("&");
                ++ingredientId;
            }
            else {
                serviceURL.append("ingredient").append(i).append("=").append(currentIngredient);
            }
        }

        SharedPreferences prefs = getSharedPreferences("Token", MODE_PRIVATE);
        String token = prefs.getString("token", "");
        //Send the ingredients
        new AsyncTaskExecutioner().execute(new SendIngredients(serviceURL.toString(), token, homeScreenActivity), (ingredientsResult) -> sendIngredientsAttempt(ingredientsResult));
    }

    // If HTTP request was successful go to next activity (list of found recipes).
    public void sendIngredientsAttempt(String recipeListData) {
        recipeListData = recipeListData.replace("\\", "");
        if(!recipeListData.equals("Service error.") && !recipeListData.equals("Network error.") && !recipeListData.equals("Recipes were not found.")) {
            Intent intent = new Intent(this, FoundRecipesList.class);

            SharedPreferences.Editor editor = getSharedPreferences("FoundRecipeListData", MODE_PRIVATE).edit();
            editor.putString("FoundRecipeListData", recipeListData);
            editor.apply();

            startActivity(intent);
        }
        else {
            enteredIngredient.setError(getResources().getString(R.string.rest_recipes_not_found));
        }
    }
}