package si.uni_lj.fe.seminar.autorecipe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class RecipePage extends AppCompatActivity {

    TextView selectedRecipeName;
    TextView selectedRecipeDescription;
    TextView selectedRecipeIngredients;

    String thumbnailUrl;

    RecipePage recipePage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_page);

        this.recipePage = this;

        selectedRecipeName = findViewById(R.id.selected_recipe_name);
        selectedRecipeDescription = findViewById(R.id.selected_recipe_description);
        selectedRecipeIngredients = findViewById(R.id.selected_recipe_ingredients);

        SharedPreferences prefs = getSharedPreferences("selectedRecipeData", MODE_PRIVATE);

        //If the thumbnail image isn't provided ignore the code that fetches it through the link, the default placeholder from res will be shown
        if(prefs.getString("recipeThumbnail", "") != "") {
            ImageView thumbnail = findViewById(R.id.recipe_thumbnail_image);
            thumbnailUrl = getResources().getString(R.string.URL_API) + prefs.getString("recipeThumbnail", "");
            Picasso.get().load(thumbnailUrl).into(thumbnail);
        }

        selectedRecipeName.setText(prefs.getString("recipeName", "Recipe name not found!"));
        selectedRecipeDescription.setText(prefs.getString("recipeDescription", "Description not found!"));
        selectedRecipeIngredients.setText(prefs.getString("recipeIngredients", "Ingredients not found!"));
    }

    public void beginPreparation(View view) {
        Intent intent = new Intent(this, RecipeStep.class);

        SharedPreferences.Editor editor = getSharedPreferences("currentRecipeStep", MODE_PRIVATE).edit();
        editor.putInt("currentRecipeStep", 1);
        editor.apply();

        startActivity(intent);
    }
}