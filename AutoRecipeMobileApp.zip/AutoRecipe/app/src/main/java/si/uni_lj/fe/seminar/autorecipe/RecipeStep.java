package si.uni_lj.fe.seminar.autorecipe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class RecipeStep extends AppCompatActivity {

    String pictureUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_step);

        TextView recipeStepTextView = findViewById(R.id.recipe_step_text);

        SharedPreferences prefsCurrentStep = getSharedPreferences("currentRecipeStep", MODE_PRIVATE);
        int i = prefsCurrentStep.getInt("currentRecipeStep", 1);

        SharedPreferences prefsCurrentStepData = getSharedPreferences("selectedRecipeData", MODE_PRIVATE);

        String currentRecipeStepPicture = "step" + i + "_picture";
        //Try loading the step's picture, if it's not provided then ignore this code, the default placeholder from res will be shown
        ImageView recipeStepPicture = findViewById(R.id.recipe_step_picture);
        if(prefsCurrentStepData.getString(currentRecipeStepPicture, "") != "") {
            pictureUrl = getResources().getString(R.string.URL_API) + prefsCurrentStepData.getString(currentRecipeStepPicture, "");
            Picasso.get().load(pictureUrl).into(recipeStepPicture);
        }
        else {
            recipeStepPicture.setImageResource(R.drawable.image_not_found);
        }

        String currentRecipeStepText = "step" + i + "_text";
        String recipeStepText = prefsCurrentStepData.getString(currentRecipeStepText, "Step text not found!");
        recipeStepTextView.setText(recipeStepText);
    }

    public void previousStep(View view) {
        SharedPreferences prefs = getSharedPreferences("currentRecipeStep", MODE_PRIVATE);
        int i = prefs.getInt("currentRecipeStep", 1);

        if(i != 1) {
            --i;

            SharedPreferences.Editor editor = getSharedPreferences("currentRecipeStep", MODE_PRIVATE).edit();
            editor.putInt("currentRecipeStep", i);
            editor.apply();

            changeStepPage();
        } else {
            Button previousStep = findViewById(R.id.previous_step_button);
            previousStep.setError("this is the first step dummy");
        }
    }

    public void nextStep(View view) {
        SharedPreferences prefs = getSharedPreferences("currentRecipeStep", MODE_PRIVATE);
        int i = prefs.getInt("currentRecipeStep", 1);

        SharedPreferences prefsMaxStep = getSharedPreferences("selectedRecipeData", MODE_PRIVATE);
        int lastStep = prefsMaxStep.getInt("numberOfSteps", 1);

        if(i != lastStep) {
            ++i;

            SharedPreferences.Editor editor = getSharedPreferences("currentRecipeStep", MODE_PRIVATE).edit();
            editor.putInt("currentRecipeStep", i);
            editor.apply();

            changeStepPage();
        } else {
            Button nextStep = findViewById(R.id.next_step_button);
            nextStep.setError("this is the last step dummy");
        }
    }

    public void changeStepPage() {
        TextView recipeStepTextView = findViewById(R.id.recipe_step_text);

        SharedPreferences prefsCurrentStep = getSharedPreferences("currentRecipeStep", MODE_PRIVATE);
        int i = prefsCurrentStep.getInt("currentRecipeStep", 1);

        SharedPreferences prefsCurrentStepData = getSharedPreferences("selectedRecipeData", MODE_PRIVATE);

        String currentRecipeStepPicture = "step" + i + "_picture";
        //Try loading the step's picture, if it's not provided then ignore this code, the default placeholder from res will be shown
        if(prefsCurrentStepData.getString(currentRecipeStepPicture, "") != "") {
            ImageView recipeStepPicture = findViewById(R.id.recipe_step_picture);
            pictureUrl = getResources().getString(R.string.URL_API) + prefsCurrentStepData.getString(currentRecipeStepPicture, "");
            Picasso.get().load(pictureUrl).into(recipeStepPicture);
        }

        String currentRecipeStepText = "step" + i + "_text";
        String recipeStepText = prefsCurrentStepData.getString(currentRecipeStepText, "Step text not found!");
        recipeStepTextView.setText(recipeStepText);
    }
}