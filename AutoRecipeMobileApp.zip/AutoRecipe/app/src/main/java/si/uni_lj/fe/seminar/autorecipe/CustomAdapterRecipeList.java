package si.uni_lj.fe.seminar.autorecipe;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.Objects;

public class CustomAdapterRecipeList extends BaseAdapter {
    Context context;
    String[] recipeNames;
    String[] recipeIDs;
    String[] recipeThumbnails;
    LayoutInflater inflater;

    public CustomAdapterRecipeList(Context applicationContext, String[] recipeNames, String[] recipeIDs, String[] recipeThumbnails) {
        this.context = context;
        this.recipeNames = recipeNames;
        this.recipeIDs = recipeIDs;
        this.recipeThumbnails = recipeThumbnails;
        inflater = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        return recipeNames.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.activity_found_recipes_list_element, null);

        //If the thumbnail image isn't provided ignore the code that fetches it through the link, the default placeholder from res will be shown
        if(!Objects.equals(recipeThumbnails[i], "")) {
            ImageView recipeThumbnail = view.findViewById(R.id.recipe_list_thumbnail);
            String thumbnailUrl = "http://10.0.2.2/AutoRecipe/" + recipeThumbnails[i];
            Picasso.get().load(thumbnailUrl).into(recipeThumbnail);
        }

        TextView recipeThumbnailPath = view.findViewById(R.id.recipe_list_thumbnail_path);
        recipeThumbnailPath.setText(recipeThumbnails[i]);

        TextView recipeName = view.findViewById(R.id.recipe_list_name);
        recipeName.setText(recipeNames[i]);

        TextView recipeID = view.findViewById(R.id.recipe_list_id);
        recipeID.setText(recipeIDs[i]);

        return view;
    }
}
